// Basic social networking site (frontend + backend integration ready)
// This is the React frontend with placeholder functions for backend APIs

import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function SocialApp() {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState("");
  const [user, setUser] = useState({ id: 1, name: "John Doe" });

  useEffect(() => {
    // Fetch posts from backend
    fetch("/api/posts")
      .then((res) => res.json())
      .then((data) => setPosts(data));
  }, []);

  const handlePost = () => {
    if (!newPost) return;
    const post = {
      userId: user.id,
      content: newPost,
      date: new Date().toISOString(),
    };
    fetch("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(post),
    })
      .then((res) => res.json())
      .then((savedPost) => setPosts([savedPost, ...posts]));
    setNewPost("");
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">ConnectMe - Social Feed</h1>
      <div className="mb-4">
        <Input
          placeholder="What's on your mind?"
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
        />
        <Button className="mt-2" onClick={handlePost}>
          Post
        </Button>
      </div>
      {posts.map((post, i) => (
        <Card key={i} className="mb-4">
          <CardContent>
            <p className="text-sm text-gray-500">{post.date}</p>
            <p className="font-semibold">{post.content}</p>
            <p className="text-sm">Posted by User {post.userId}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
